package com.progra.interfaces;

public interface AdvancedArithmetic {

    int divisorSum(int n);

}
